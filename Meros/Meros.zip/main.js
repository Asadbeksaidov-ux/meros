document.getElementById('booking-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Formaning standart yuborilishini to'xtatish

    const form = event.target;
    
    // Forma ma'lumotlarini EmailJS shabloni uchun yig'ish (templateParams)
    // Ob'yekt ichidagi nomlar sizning EmailJS shabloningizdagi {{...}} nomlariga mos kelishi kerak.
    const templateParams = {
        // Aloqa va Asosiy Ma'lumotlar
        full_name: form.querySelector('[name="fullName"]').value,
        email: form.querySelector('[name="email"]').value,
        check_in: form.querySelector('[name="checkInDate"]').value,
        check_out: form.querySelector('[name="checkOutDate"]').value,
        phone_number: form.querySelector('[name="phoneNumber"]').value || 'Kiritilmagan',
        adults: form.querySelector('[name="adults"]').value,
        children: form.querySelector('[name="children"]').value,
        additional_notes: form.querySelector('[name="additionalNotes"]').value || 'Yo\'q',
        
        // Xona Buyurtmasi
        qty_double: form.querySelector('[name="qty_double"]').value,
        qty_twin: form.querySelector('[name="qty_twin"]').value,
        qty_triple: form.querySelector('[name="qty_triple"]').value,
        qty_double_balcony: form.querySelector('[name="qty_double_balcony"]').value,
        qty_twin_balcony: form.querySelector('[name="qty_twin_balcony"]').value,
    };

    // ⚠️ O'zgartirish kerak: YOUR_SERVICE_ID va YOUR_TEMPLATE_ID
    // EmailJS xizmati orqali yuborish
    emailjs.send('service_n4nb5ob', 'template_59tfqm9', templateParams)
        .then(function(response) {
            // Muvaffaqiyatli yuborish
            console.log('SUCCESS!', response.status, response.text);
            
            // Xabar berish va formani tozalash
            alert('✅ Your booking request has been successfully sent!');
            form.reset(); 
            
            // Xohlasangiz, formadagi xato xabarini (alert) yashirishingiz mumkin
            // document.getElementById('room-selection-alert').style.display = 'none';

        }, function(error) {
            // Xatolik yuz bergan holat
            console.log('FAILED...', error);
            alert('❌ An error occurred. Please try again.');
        });
});